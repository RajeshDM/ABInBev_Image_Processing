import cv2
import numpy as np

img = cv2.imread("Focus_Area/Shelf_Image_Dataset/Supermarket_2015-01-04.jpg")
#crop_img = img[728:807, 5:4500] # Crop from x, y, w, h -> 100, 200, 300, 400
crop_img = img[1792:1871, 37:4532] 
#crop_img = img[2823:2902, 5:4500] 
# NOTE: its img[y: y + h, x: x + w] and *not* img[x: x + w, y: y + h]
cv2.imshow("cropped", crop_img)
cv2.namedWindow('image',0)
cv2.imshow("image", img)
cv2.resizeWindow("image", 500,500);

# convert to grayscale and detect edges
gray = cv2.cvtColor(crop_img, cv2.COLOR_BGR2GRAY)
edge = cv2.Canny(gray, 20, 20 * 3, 3)
cv2.imshow("edges", edge)

#morphological
kernel = np.ones((5,5),np.uint8)
dilation = cv2.dilate(edge,kernel,iterations = 1)
erosion = cv2.erode(dilation,kernel,iterations = 10)
dilation = cv2.dilate(erosion,kernel,iterations = 10)
cv2.imshow("dilatte", dilation)

# find contours
hh, ww = dilation.shape[:2]
rect = np.zeros((hh, ww, 1), np.uint8)
contours0, hierarchy = cv2.findContours(dilation,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
contours = [cv2.approxPolyDP(cnt, 3, True) for cnt in contours0]

# sort by area
areaArray = []
for i in contours:
    area = cv2.contourArea(i)
    areaArray.append(area)
sorteddata = sorted(zip(areaArray, contours), key=lambda x: x[0], reverse=True)
secondlargestcontour = sorteddata[1][1]
largestarea = cv2.contourArea(secondlargestcontour)

# bounding rectangle
num = 0
for i in contours:
	if (cv2.contourArea(i) >= (largestarea/2) ): #only big rectangles
		x,y,w,h = cv2.boundingRect(i)
		cv2.rectangle(rect,(x,y),(x+w,y+h),(255,255,255),-1)
		label_img = crop_img[y:y+h, x:x+w]
		cv2.imwrite("images/1_"+str(num)+".png",label_img)
		num = num +1
#os.makedirs("path")
#cv2.imshow("label_img", label_img)

# masked rectangle images
res = cv2.bitwise_and(crop_img,crop_img,mask = rect)
cv2.imshow("rectangle", res)


	
cv2.waitKey(0)
