import cv2

import numpy as np

from crop_save import *

def templateMatch(img, template):

	w, h = template.shape[::-1]

	# All the 6 methods for comparison in a list

	methods = ['cv2.TM_CCOEFF', 'cv2.TM_CCOEFF_NORMED', 'cv2.TM_CCORR',

            'cv2.TM_CCORR_NORMED', 'cv2.TM_SQDIFF', 'cv2.TM_SQDIFF_NORMED']

	#for meth in methods:

	meth ='cv2.TM_CCOEFF'



	method = eval(meth)

	# Apply template Matching

	res = cv2.matchTemplate(img,template,method)

	min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)

	# If the method is TM_SQDIFF or TM_SQDIFF_NORMED, take minimum

	if method in [cv2.TM_SQDIFF, cv2.TM_SQDIFF_NORMED]:

		top_left = min_loc

	else:

		top_left = max_loc

	bottom_right = (top_left[0] + w, top_left[1] + h)

	hh, ww = img.shape[:2]

	rect = np.zeros((hh, ww, 1), np.uint8) 

	cv2.rectangle(rect,top_left, bottom_right, 255, -1)

	rect=cv2.bitwise_not(rect)

	img = cv2.bitwise_and(img, img, mask=rect)

	return img, top_left, bottom_right

	#cv2.namedWindow('image',0)

	#cv2.imshow("image", op)

	#cv2.resizeWindow("image", 500,500);

	#cv2.waitKey(0)

	

def templateMatch1(img, template):

	w, h = template.shape[::-1]

	# All the 6 methods for comparison in a list

	methods = ['cv2.TM_CCOEFF', 'cv2.TM_CCOEFF_NORMED', 'cv2.TM_CCORR',

            'cv2.TM_CCORR_NORMED', 'cv2.TM_SQDIFF', 'cv2.TM_SQDIFF_NORMED']

	#for meth in methods:

	meth ='cv2.TM_CCOEFF'



	method = eval(meth)

	# Apply template Matching

	res = cv2.matchTemplate(img,template,method)

	min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)

	# If the method is TM_SQDIFF or TM_SQDIFF_NORMED, take minimum

	if method in [cv2.TM_SQDIFF, cv2.TM_SQDIFF_NORMED]:

		top_left = min_loc

	else:

		top_left = max_loc

	bottom_right = (top_left[0] + w, top_left[1] + h)

	hh, ww = img.shape[:2]

	rect = np.zeros((hh, ww, 1), np.uint8) 

	rect1 = np.ones((hh, ww, 1), np.uint8)

	cv2.rectangle(rect,top_left, bottom_right, 255, -1)

	rect=cv2.bitwise_not(rect)

	#cv2.imshow(rect1)

	op = cv2.bitwise_and(img, img, mask=rect)

	#return  top_left, bottom_right

	cv2.namedWindow('image',0)

	cv2.imshow("image", op)

	cv2.resizeWindow("image", 500,500);

	cv2.waitKey(0)

	



def dictMatch(s):

	img2 = cv2.imread(s)	

	img = cv2.cvtColor( img2, cv2.COLOR_RGB2GRAY )

	#template = cv2.imread('31.jpg',0)

	#templateMatch1(img, template)



	#top_left, bottom_right= templateMatch(img, template)



	templates = {'11.jpg':('SIERRA NEVADA PALE ALE', '6 Pk 12 Oz Glass')

	, '12.jpg':('SIERRA NEVADA TORPEDO', '6 Pk 12 Oz Glass'), '13.jpg':('BLUE POINT TOASTED', '6 Pk 12 Oz Glass'), '14.jpg':('MAGIC HAT' , '6 Pk 12 Oz Glass'), '15.jpg':('BROOKLYN PILSNER', '6 Pk 12 Oz Glass'), '16.jpg': ('BROOKLYN INDIA PALE', '6 Pk 12 Oz Glass'), '17.jpg': ('BROOKLYN OKTOBERFEST', '6 Pk 12 Oz Glass'), '21.jpg': ('CORONA EXTRA', '6 Pk 12 Oz Glass'), '22.jpg': ('CORONA EXTRA', '6 Pk 12 Oz Glass'), '23.jpg': ('CORONA LIGHT', '6 Pk 12 Oz Glass'), '24.jpg': ('STELLA ARTOIS', '6 Pk 11.2 Oz Glass'), '25.jpg': ('STELLA ARTOIS', '6 Pk 11.2 Oz Glass'), '26.jpg': ('LEFFE BLONDE', '6 Pk 11.2 Oz Glass'), '27.jpg': ('HOEGAARDEN', '6 Pk 11.2 Oz Glass'), '28.jpg': ('BECKS','6 Pk 12 Oz Glass'), '31.jpg': ('MILLER LITE', '6 Pk 12 Oz Glass'), '32.jpg': ('COORS LIGHT', '6 Pk 12 Oz Glass')

	, '33.jpg': ('BUD LIGHT PLATINUM', '6 Pk 12 Oz Glass'), '34.jpg': ('BUD LIGHT', '6 Pk 12 Oz Glass'), '35.jpg': ('BUDWEISER', '6 Pk 12 Oz Glass'), '36.jpg': ('MILLER LITE', '12 Pk 12 Oz Glass')

	, '37.jpg': ('MILLER LITE', '12 Pk 12 Oz Glass')}

	#print img2.shape

	d = get_bounding_rect_coords(img2)

	op = {}

	for i in range(1, 4):

		for j in range(1,8):

			tem1 = str(i) + str(j) + ".jpg"

			tem = "templates/" + tem1

			#print tem

			template = cv2.imread(tem,0)

			img, top_left, bottom_right = templateMatch(img, template)

			tl = [top_left[0], top_left[1], bottom_right[0], bottom_right[1]]

			#print tl

			vert = {}

			for k in d:

				l = d[k]

				if(	(tl[0] < l[2] and l[2] < tl[2]) or (tl[2] > l[0] and l[0] > tl[0])):

					vert[k] = l

			if len(vert) != 0:

				mini = abs(vert[list(vert)[0]][1] - tl[3])

				index = list(vert)[0]

			#print vert, mini, index

			for r in vert:

				diff = abs(vert[r][1] - tl[3])

				#print diff, r

				if (mini > diff):

					mini = diff

					index = r

		

			op[str(i)+"_"+str(j)] = [templates[tem1][0],templates[tem1][1]]
			#(i,j)
			if(tem[-6] != index[0] or tem[-5] != index[2]):		

				print tem, index

	return op

			

#dictMatch('image.jpg')	
