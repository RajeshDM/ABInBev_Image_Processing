import cv2
import numpy as np
import os


def sort_contours(cnts, method="left-to-right"):
	# initialize the reverse flag and sort index
	reverse = False
	i = 0
 
	# handle if we need to sort in reverse
	if method == "right-to-left" or method == "bottom-to-top":
		reverse = True
 
	# handle if we are sorting against the y-coordinate rather than
	# the x-coordinate of the bounding box
	if method == "top-to-bottom" or method == "bottom-to-top":
		i = 1
 
	# construct the list of bounding boxes and sort them from top to
	# bottom
	boundingBoxes = [cv2.boundingRect(c) for c in cnts]
	(cnts, boundingBoxes) = zip(*sorted(zip(cnts, boundingBoxes),
		key=lambda b:b[1][i], reverse=reverse))
 
	# return the list of sorted contours and bounding boxes
	return (cnts, boundingBoxes)



def get_labels_from_row(crop_img, row, date,x1, y1, flag):
	# convert to grayscale and detect edges
	gray = cv2.cvtColor(crop_img, cv2.COLOR_BGR2GRAY)
	edge = cv2.Canny(gray, 20, 20 * 3, 3)
	#cv2.imshow("edges", edge)

	#morphological
	kernel = np.ones((5,5),np.uint8)
	dilation = cv2.dilate(edge,kernel,iterations = 1)
	erosion = cv2.erode(dilation,kernel,iterations = 10)
	dilation = cv2.dilate(erosion,kernel,iterations = 10)
	#cv2.imshow("dilatte", dilation)

	# find contours
	hh, ww = dilation.shape[:2]
	rect = np.zeros((hh, ww, 1), np.uint8)
	contours0, hierarchy = cv2.findContours(dilation,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
	contours = [cv2.approxPolyDP(cnt, 3, True) for cnt in contours0]

	# sort by area
	areaArray = []
	for i in contours:
	    area = cv2.contourArea(i)
	    areaArray.append(area)
	sorteddata = sorted(zip(areaArray, contours), key=lambda x: x[0], reverse=True)
	secondlargestcontour = sorteddata[1][1]
	largestarea = cv2.contourArea(secondlargestcontour)

	dict_coords = {}
	contours, boundrect = sort_contours(contours)
	# bounding rectangle
	num = 0
	for i in contours:
		if (cv2.contourArea(i) >= (largestarea/2) ): #only big rectangles
			x,y,w,h = cv2.boundingRect(i)
			if (flag == 0): #only want coordinates
				dict_coords[str(row)+"_"+str(num+1)] = [x+x1,y+y1,x+w+x1, y+h+y1]
			else: #write image to file
				cv2.rectangle(rect,(x,y),(x+w,y+h),(255,255,255),-1)
				label_img = crop_img[y:y+h, x:x+w]
				if (os.path.isdir("images/"+str(date)) == False):
					os.makedirs("images/"+str(date))
				cv2.imwrite("images/"+str(date)+"/"+str(date)+"_"+str(row)+"_"+str(num+1)+".jpg",label_img)
			num = num +1
	#os.makedirs("path")
	#cv2.imshow("label_img", label_img)

	# masked rectangle images
	#res = cv2.bitwise_and(crop_img,crop_img,mask = rect)
	#cv2.imshow("rectangle", res)
	return dict_coords






def deal_with_image(img, date, flag):
	new_d = {}
	crop_img1 = img[728:807, 5:4580] 
	crop_img2 = img[1792:1871, 5:4580] 
	crop_img3 = img[2823:2902, 5:4500] 
	new_d.update(get_labels_from_row(crop_img1, 1, date, 5,728, flag))
	new_d.update(get_labels_from_row(crop_img2, 2, date, 5,1792,  flag))
	new_d.update(get_labels_from_row(crop_img3, 3, date, 5,2823,  flag))
	#cv2.imshow("cropped", crop_img)
	return new_d	
	#cv2.waitKey(0)

def test(): #ignore function. used for testing
	img = cv2.imread("Focus_Area/Shelf_Image_Dataset/Supermarket_2015-01-04.jpg")
	d = deal_with_image(img, "ll", 0)
	hh, ww = img.shape[:2]
	rect = np.zeros((hh, ww, 1), np.uint8)
	for i in d:
		val = d[i]
		cv2.rectangle(rect,(val[0],val[1]),(val[2],val[3]),(255,255,255),-1)
	cv2.namedWindow('image',0)
	cv2.imshow("image", rect)
	cv2.resizeWindow("image", 500,500);
	cv2.namedWindow('image2',0)
	cv2.imshow("image2", img)
	cv2.resizeWindow("image2", 500,500);
	print d
	cv2.waitKey(0)

# inpput - image.. output - dictionary of coordinates
#d["1_1"] = [x1, y1, x2, y2]
def get_bounding_rect_coords(img):
	d = deal_with_image(img, "ll", 0)
	return d


if __name__ == '__main__':
	#img = cv2.imread("Focus_Area/Shelf_Image_Dataset/Supermarket_2015-01-04.jpg")
	directory = "Focus_Area/Shelf_Image_Dataset"
	for filename in os.listdir(directory):
	    if filename.endswith(".jpg"): 
		date = filename[12:22]
		#print date
		#print(os.path.join(directory, filename))
		img = cv2.imread(os.path.join(directory, filename))
		if (not img is None):
			d = deal_with_image(img, date, 1)
		continue
	    else:
		continue

