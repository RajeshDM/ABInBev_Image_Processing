from difflib import SequenceMatcher
import re
import os,sys
'''
os.system('chmod +x trial.sh')
os.system('./trial.sh')
'''
import csv

def isNumCharDollar(val):
	ret = 0
	if (val<='9' and val>='0'):
		ret = 1
	if (val<='Z' and val>='A'):
		ret = 1
	if (val<='z' and val>='a'):
		ret =1
	if(val=='$'):
		ret = 1
	return ret

def isAlpha(val):
	ret = 0
	if (val<='Z' and val>='A'):
		ret = 1
	if (val<='z' and val>='a'):
		ret =1
	return ret

f = open('PriceList.csv')
exData = csv.reader(f)
PriceOrgData = zip(*list(exData))
print len(PriceOrgData)
DrinkNames = PriceOrgData[0]
QuantityNames = PriceOrgData[1]
PriceTags = PriceOrgData[2]

#i = 22

def getOcrData(path):

	ocr_data = {}
	#for foldername in os.listdir(path):
	foldername = '2015-07-12'
	#for filename in os.listdir(path+foldername+'/'):
	filename = '2015-07-12_3_3.jpg.txt'
	if(filename.endswith('.txt')):
		location = path+foldername+'/'+filename
		print location
		f = open(location, 'r')
		prefiltered = filter(lambda x: not re.match(r'^\s*$', x), f.read().decode('utf-8').strip().split('\n'))
		filtered = [x for x in prefiltered if (len(x) >3 and isNumCharDollar(x[0]))]
		if(len(filtered) >= 3):
			name = filtered[0]
			quantity = filtered[1]
			if(quantity[0] == '2'):
				quantity = '6' + quantity[1:]
			price = filtered[2]
			price = price.split('$')[-1]
			price = price[:-1] + '9'
			if(isAlpha(price[-2])):
				price = price[:-2] + '9' + price[-1]
			price = price[:-2]+'.'+price[-2:]
			bestName = ""
			bestNameRatio = 0
			for val in DrinkNames:
				if(len(name)<8):
					if( len(val) <len(name)+2 and len(val)>len(name)-2):
						m = SequenceMatcher(None, val, name)
						ratio = m.ratio()
						if(ratio > bestNameRatio):
							bestName = val
							bestNameRatio = ratio
				else:
					m = SequenceMatcher(None, val, name)
					ratio = m.ratio()
					if(ratio > bestNameRatio):
						bestName = val
						bestNameRatio = ratio
			print bestName
		
			bestQuantity = ""
			bestQuantityRatio = 0
			for val in QuantityNames:
				m = SequenceMatcher(None, val, quantity)
				ratio = m.ratio()
				if(ratio > bestQuantityRatio):
					bestQuantity = val
					bestQuantityRatio = ratio
			print bestQuantity
		
			bestPrice = ""
			bestPriceRatio = 0
			for val in PriceTags:
				m = SequenceMatcher(None, val, price)
				ratio = m.ratio()
				if(ratio > bestPriceRatio):
					bestPrice = val
					bestPriceRatio = ratio
			#print bestPrice
			ocr_key = filename[:-4]
			ocr_data[ocr_key] = (bestName,bestQuantity,bestPrice)

		#i-=1
		#if i==0 :
		#	exit()
	return ocr_data

ocr_data = getOcrData('/home/rajesh/Hackathon/ABInBev/image_extractor/new_images/')
print ocr_data
