#include <cv.h>
#include <highgui.h>
#include <opencv2/opencv.hpp>
#include <iostream>
#include <string>
#include <cstring>
#include <dirent.h>

using namespace cv;
using namespace std;

double alpha; /**< Simple contrast control */
int beta;  /**< Simple brightness control */

void iterate_over_directories( string PATH )         // in this directory,
{
    //const char* PATH = ".";
    DIR *dir = opendir(PATH.c_str());
    struct dirent *entry = readdir(dir);

    while (entry != NULL)
    {
        if (entry->d_type == DT_DIR) {
        	printf ("folder:%s\n", entry->d_name);
        	
        	string entry_temp(entry->d_name);
        	if(entry_temp.length() < 3){
        			entry = readdir(dir);
        			continue;
        		}
        	       	
        	DIR *dir2 = opendir((PATH + entry_temp + "/").c_str());
        	struct dirent *entry2 =readdir(dir2);
        	
        	while(entry2 != NULL) {
        		printf ("file:%s\n", entry2->d_name);

        		string entry2_temp(entry2->d_name);
        		if(entry2_temp.length() < 3){
        			entry2 = readdir(dir2);
        			continue;
        		}
        		
        		Mat image = imread(PATH + entry_temp + "/" + entry2_temp);
        		cv::Rect roi(56,0, image.size().width-56, image.size().height-3);
        		image = image(roi);
        		image.convertTo(image, -1, 2.0, -100);
        		//cvSet(image, CV_RGB(255,255,255));
        		imwrite("/home/devarsh/Desktop/Krishna/new_images/"+ entry_temp + "/" + entry2_temp, image);
        		
        	entry2 = readdir(dir2);	
        	}
        	
        	closedir(dir2);
        }

        entry = readdir(dir);
    }

    closedir(dir);
}


int main( int argc, char** argv )
{
	
	string	path = "/home/devarsh/Desktop/Krishna/images/";
	iterate_over_directories(path);
	
	/*
	/// Read image given by user
	Mat image = imread( argv[1] );
	Mat new_image = Mat::zeros( image.size(), image.type() );

	std::cout<<image.size().height<<" "<<image.size().width<<std::endl;

	//Crop
	cv::Rect roi(55,15, image.size().width-8-55, image.size().height-17);
	/*roi.x = 55;
	roi.y = 15;
	roi.width = image.size().width - 15;
	roi.height = image.size().height - 2;*/

	// Crop the full image to that image contained by the rectangle myROI
	// Note that this doesn't copy the data
	/*image = image(roi);

	/// Initialize values
	alpha = 2.0;
	beta = -100;

	/// Do the operation new_image(i,j) = alpha*image(i,j) + beta
	image.convertTo(new_image, -1, alpha, beta);

	/// Create Windows
	namedWindow("Original Image", 1);
	namedWindow("New Image", 1);

	/// Show stuff
	imshow("Original Image", image);
	imshow("New Image", new_image);

	//Save
	imwrite("new2.jpg",new_image);

	/// Wait until user press some key
	waitKey();
	
	*/
	return 0;
}
