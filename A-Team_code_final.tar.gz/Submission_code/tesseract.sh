#!/bin/bash

for file in new_images/*
do
	echo $file
	for image_file in $file/*
	do
		echo $image_file
		tesseract $image_file $image_file -l eng
		#if [[ $file == *.txt ]]
		#then
		#	rm $image_file
		#fi
	done
done
