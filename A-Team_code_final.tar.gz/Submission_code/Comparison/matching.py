import cPickle 
import cv2
import numpy as np
from crop_save import *
from template import *
import os
import sys
import re
import pickle

ocr_data = pickle.load( open( "ocr_dict.pkl", "rb" ) )

#print "done reading pickle file"
#ocr_data = load_obj("ocr_dict")

template_dict = dictMatch('image.jpg')#load_obj("template_dict")

favorite_color = { "lion": "yellow", "kitty": "red" }
pickle.dump( favorite_color, open( "save.p", "wb" ) )


#print template_dict

print ocr_data['2015-02-01_1_2.jpg']

#for i in range(1,4):
#	for j in range (1,9):

mismatch = 0 

#print "starting comparison"

flag = 0 

mismatch_position_name = []
mismatch_position_quantity = []
ocr_data_mismatch_name = []
ocr_data_mismatch_quantity = []

only_name_ocr_mismatches = {}
quantity_mismatches = {}

for key,value in ocr_data.iteritems() :
	position = key[-7:-4]
	
	flag = 0 
	if position in template_dict :
		if value[0] != template_dict[position][0] :
			mismatch += 1
			#flag = 1
			#mismatch_position_name.append((key,'name'))
			#ocr_data_mismatch_name.append(value)
			mismatch_position_name.append((key,template_dict[position][0],value[0]))
			only_name_ocr_mismatches[key] = value
			#all_mismatches[key] = value

		elif value[1] != template_dict[position][1]:# and flag == 0 :
			mismatch += 1

			quantity_mismatches[key] = value
			#mismatch_position_quantity.append((key,'quantity'))
			#ocr_data_mismatch_quantity.append(value)
#print mismatch_position

###########################################################################################################
updated_ocr = {}

for key, value in quantity_mismatches.iteritems():
	date = key[:-7]	
	updated_ocr[date] = []
		
for key, value in quantity_mismatches.iteritems():	
	date = key[:-7]	
	position = key[-7:-4]
	updated_ocr[date].append((position,value))

leftover = [] 

for key,value in updated_ocr.iteritems():

	for i in range(0,len(updated_ocr[key])-1):
		if abs(int(updated_ocr[key][i][0][-1]) - int(updated_ocr[key][i+1][0][-1])) == 1 and int(updated_ocr[key][i][0][0]) - int(updated_ocr[key][i+1][0][0])  == 0: 
			leftover.append((key,value))

#''' 2_1 '''
########################################################################################################################################

updated_ocr_2 = {}

for key, value in only_name_ocr_mismatches.iteritems():
	date = key[:-7]	
	updated_ocr_2[date] = []
		
for key, value in only_name_ocr_mismatches.iteritems():	
	date = key[:-7]	
	position = key[-7:-4]
	updated_ocr_2[date].append((position,value))

leftover_2 = [] 

for key,value in updated_ocr_2.iteritems():

	for i in range(0,len(updated_ocr_2[key])-1):
		if abs(int(updated_ocr_2[key][i][0][-1]) - int(updated_ocr_2[key][i+1][0][-1])) == 1 and int(updated_ocr_2[key][i][0][0]) - int(updated_ocr_2[key][i+1][0][0])  == 0: 
			leftover_2.append((key,value))


################################################################################################################################
print len(leftover)
print len(leftover_2)

print leftover
print leftover_2


#print mismatch
#print len(mismatch_position_name)
#print len(mismatch_position_quantity)
#for element in mismatch_position_name :
#	print element
#print ocr_data_mismatch_name

