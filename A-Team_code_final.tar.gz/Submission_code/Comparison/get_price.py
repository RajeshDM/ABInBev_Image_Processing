from difflib import SequenceMatcher
import re
import os,sys
import csv
import pickle


d1 = {"SIERRA NEVADA PALE ALE_6 Pk 12 Oz Glass": "1_1", "SIERRA NEVADA TORPEDO_6 Pk 12 Oz Glass" : "1_2", "BLUE POINT TOASTED_6 Pk 12 Oz Glass":"1_3", "MAGIC HAT_6 Pk 12 Oz Glass":"1_4", "BROOKLYN PILSNER_6 Pk 12 Oz Glass":"1_5", "BROOKLYN INDIA PALE_6 Pk 12 Oz Glass":"1_6", "BROOKLYN OKTOBERFEST_6 Pk 12 Oz Glass":"1_7"}
d2 = {"CORONA EXTRA_6 Pk 12 Oz Glass":"2_1", "CORONA LIGHT_6 Pk 12 Oz Glass":"2_3", "STELLA ARTOIS_6 Pk 11.2 Oz Glass":"2_4", "LEFFE BLONDE_6 Pk 11.2 Oz Glass":"2_6", "HOEGAARDEN_6 Pk 11.2 Oz Glass":"2_7", "BECKS_6 Pk 12 Oz Glass":"2_8"}
d3 = {"MILLER LITE_6 Pk 12 Oz Glass":"3_1", "COORS LIGHT_6 Pk 12 Oz Glass":"3_2", "BUD LIGHT PLATINUM_6 Pk 12 Oz Glass":"3_3", "BUD LIGHT_6 Pk 12 Oz Glass":"3_4", "BUDWEISER_6 Pk 12 Oz Glass":"3_5", "MILLER LITE_12 Pk 12 Oz Glass":"3_6", "MILLER LITE_12 Pk 12 Oz Can":"3_7", }

d1.update(d2)
d1.update(d3)



f = open('Focus_Area/PriceList.csv')
exData = csv.reader(f)
PriceOrgData = zip(*list(exData))
print len(PriceOrgData)
DrinkNames = PriceOrgData[0]
QuantityNames = PriceOrgData[1]
PriceTags = PriceOrgData[2]

def save_obj(obj, name ):
    with open( name + '.pkl', 'wb') as f:
        pickle.dump(obj, f, pickle.HIGHEST_PROTOCOL)

def load_obj(name ):
    with open( name + '.pkl', 'rb') as f:
        return pickle.load(f)


def isNumCharDollar(val):
	ret = 0
	if (val<='9' and val>='0'):
		ret = 1
	if (val<='Z' and val>='A'):
		ret = 1
	if (val<='z' and val>='a'):
		ret =1
	if(val=='$'):
		ret = 1
	return ret

def isAlpha(val):
	ret = 0
	if (val<='Z' and val>='A'):
		ret = 1
	if (val<='z' and val>='a'):
		ret =1
	return ret

def get_price(name, quantity):
	dist = {}
	csv_file = "Focus_Area/ABI_Price_List.csv"
	with open(csv_file, 'rb') as csvfile:
		for line in csvfile.readlines():
        		array = line.split(',')
			#print array
			q = array[2].split(" ")
			q2 = q[0]+"_"+q[-1]
			name_q = array[1]+"_"+array[2]
			pos = d1[name_q]
			date = array[0][6:10]+"-"+array[0][3:5]+"-"+array[0][0:2]
			#date = array[0][0:2]+"-"+array[0][3:5]+"-"+array[0][6:10]
			#price = array[3][0:5]  
			price = array[3].strip('\n')
			#print date, price, array[3]
			k = date+"_"+array[1]+"_"+q2
			dist[k]= price
			if date == "2015-05-03":
				print k, price
	csvfile.close()
	return dist

def getOcrData(path):

	ocr_data = {}
	for foldername in os.listdir(path):
		for filename in os.listdir(path+foldername+'/'):
			if(filename.endswith('.txt')):
				location = path+foldername+'/'+filename
				#print location
				f = open(location, 'r')
				prefiltered = filter(lambda x: not re.match(r'^\s*$', x), f.read().decode('utf-8').strip().split('\n'))
				filtered = [x for x in prefiltered if (len(x) >=3 and isNumCharDollar(x[0]))]
				if (foldername == "2016-08-07"):
					print filtered
				if(len(filtered) == 3):
					name = filtered[0]
					quantity = filtered[1]
					if(quantity[0] == '2'):
						quantity = '6' + quantity[1:]
					price = filtered[2]
					price = price.split('$')[-1]
					price = price[:-1] + '9'
					if(isAlpha(price[-2])):
						price = price[:-2] + '9' + price[-1]
					price = price[:-2]+'.'+price[-2:]
					bestName = ""
					bestNameRatio = 0
					for val in DrinkNames:
						if(len(name)<8):
							if( len(val) <len(name)+2 and len(val)>len(name)-2):
								m = SequenceMatcher(None, val, name)
								ratio = m.ratio()
								if(ratio > bestNameRatio):
									bestName = val
									bestNameRatio = ratio
						else:
							m = SequenceMatcher(None, val, name)
							ratio = m.ratio()
							if(ratio > bestNameRatio):
								bestName = val
								bestNameRatio = ratio
					#print bestName
				
					bestQuantity = ""
					bestQuantityRatio = 0
					for val in QuantityNames:
						m = SequenceMatcher(None, val, quantity)
						ratio = m.ratio()
						if(ratio > bestQuantityRatio):
							bestQuantity = val
							bestQuantityRatio = ratio
					#print bestQuantity
				
					bestPrice = ""
					bestPriceRatio = 0
					for val in PriceTags:
						m = SequenceMatcher(None, val, price)
						ratio = m.ratio()
						if(ratio > bestPriceRatio):
							bestPrice = val
							bestPriceRatio = ratio
					#print bestPrice
				
					ocr_key = filename[:-4]
                    			ocr_data[ocr_key] = [(bestName,bestQuantity,bestPrice)]

			#i-=1
			#if i==0 :
			#	exit()
	return ocr_data





if __name__ == '__main__':
	f = open("price_mismatch.csv", 'wt')	
	writer = csv.writer(f)
	writer.writerow( ('Week', 'Brand', 'SKU', 'Retail price', 'Recommended price') )
	s = get_price(1,1)
	#print s
	#dd = getOcrData("/home/krishnakumar/Documents/AbInBev/Focus_Area/new_images/")	
	#print dd
	#print "saving pickle file"
	#save_obj(dd, "ocr_dict2")
	dd = load_obj("ocr_dict2")
	print dd
	errors1 = 0
	errors2 = 0
	for i in dd:
		#print i,dd[i]
		#print i, dd[i][1]
		val1= dd[i][0]
		val = str(dd[i][0][1]).split(" ")
		val2 = val[0]+"_"+val[-1]	
		k = i[0:10]+"_"+val1[0]+"_"+val2
		price = val1[2]
		#print k
		if k in s:
			p = s[k][0:-3]
			#if s[k] != price:
			if p != price[0:-3]:
				#print "discrepancy"
				print i, dd[i], s[k]
				dis = (i[0:10], val1[0], val1[1], val1[2], price)
				writer.writerow( (dis) )
				errors1 += 1
		else:
			print val1, k, "not found"
			errors2 += 1
	print errors1, errors2

	
	f.close()
	
